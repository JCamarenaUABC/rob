import React from "react";
import "./navBar.css"
//import NavBar from './navBar';

//class NavBar extends Component {
 function NavBar() {
    return(
      
  <nav className="navbar navbar-expand-lg navbar-dark bg-dark" >
  <a className="navbar-brand" href="/#"><i class="fa fa-opera green" aria-hidden="true"></i>organika</a>

 </nav>
      
    );
  }
//}

export default NavBar;

// homework
// JS arrow function this context