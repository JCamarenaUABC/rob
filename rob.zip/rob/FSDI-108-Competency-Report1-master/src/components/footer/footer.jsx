import React, { Component } from "react";

class Footer extends Component {
 render(){
    return (
    <React.Fragment>
     <div>This will contain the footer</div>  
     <div>Roberto Valdes</div>
     </React.Fragment>
    );
    }
}

export default Footer;